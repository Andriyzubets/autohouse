<?php
$_['heading_title']    = 'Basic Captcha';

// Text
$_['text_success']	   = 'Настройки Basic Captcha успешно обновлены!';
$_['text_edit']        = 'Редактирование Basic Captcha';
$_['text_extension']   = 'Captcha';

// Entry
$_['entry_status']     = 'Статус';

// Error
$_['error_permission'] = 'У вас нет прав для управления этим модулем!';
