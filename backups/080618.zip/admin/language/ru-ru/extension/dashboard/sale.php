<?php
// Heading
$_['heading_title'] = 'Всего продаж';

// Text
$_['text_extension']   = 'Панель управления';
$_['text_success']     = 'Панель продаж успешно изменена!';
$_['text_edit']        = 'Редактировать';
$_['text_view']        = 'Подробнее...';

// Entry
$_['entry_status']     = 'Статус';
$_['entry_sort_order'] = 'Сортировка';
$_['entry_width']      = 'Ширина';

// Error
$_['error_permission'] = 'У вас нет прав для управления этим модулем!';
