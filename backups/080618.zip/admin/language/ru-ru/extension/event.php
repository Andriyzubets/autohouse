<?php
// Heading
$_['heading_title']     = 'События';

// Text
$_['text_success']      = 'Событие успешно изменено!';
$_['text_list']         = 'Список событий';
$_['text_event']        = 'Используйте событие что бы переопределить функционал того или иного дополнения';

// Column
$_['column_code']       = 'Код события';
$_['column_trigger']    = 'Триггер';
$_['column_action']     = 'Действие';
$_['column_status']     = 'Статус';
$_['column_date_added'] = 'Добавлен';
$_['column_action']     = 'Действие';

// Error
$_['error_permission']  = 'У вас не достаточно прав!';
