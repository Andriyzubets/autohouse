<?php
// Heading
$_['heading_title']     	= 'Учитывать в заказе';

// Text
$_['text_success']          = 'Заказ успешно обновлен!';
$_['text_list']         	= 'Учитывать в заказе';

// Column
$_['column_name']          	= 'Учитывать в заказе';
$_['column_status']         = 'Статус';
$_['column_sort_order']     = 'Сортировки';
$_['column_action']         = 'Действие';

// Error
$_['error_permission']      = 'У вас нет прав для управления этим модулем!';
