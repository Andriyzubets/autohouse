<?php
// header
$_['heading_title']  	  = 'Вход';

// Text
$_['text_heading']        = 'Вход';
$_['text_login']          = 'Введите логин и пароль';
$_['text_forgotten']      = 'Забыли пароль?';

// Entry
$_['entry_username']      = 'Логин';
$_['entry_password']      = 'Пароль';

// Button
$_['button_login']        = 'Войти';

// Error
$_['error_login']         = 'Неправильный логин и/или пароль!';
$_['error_token']         = 'Неправильная токен-сессия. Авторизуйтесь снова.';
