<?php
// Heading
$_['heading_title']	   = 'Журнал ошибок';

// Text
$_['text_success']	   = 'Журнал ошибок успешно очищен!';
$_['text_list']        = 'Список ошибок';

// Error
$_['error_warning']	   = 'ВНИМАНИЕ: Your error log file %s is %s!';
$_['error_permission'] = 'У вас нет прав что бы очистить журнал ошибок!';
