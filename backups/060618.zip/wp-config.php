<?php
/**
 * Основные параметры WordPress.
 *
 * Скрипт для создания wp-config.php использует этот файл в процессе
 * установки. Необязательно использовать веб-интерфейс, можно
 * скопировать файл в "wp-config.php" и заполнить значения вручную.
 *
 * Этот файл содержит следующие параметры:
 *
 * * Настройки MySQL
 * * Секретные ключи
 * * Префикс таблиц базы данных
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** Параметры MySQL: Эту информацию можно получить у вашего хостинг-провайдера ** //
/** Имя базы данных для WordPress */
define('WP_CACHE', true);
define( 'WPCACHEHOME', '/var/www/cdaslco17411/data/www/asl.com.ua/wp-content/plugins/wp-super-cache/' );
define('DB_NAME', 'asl');

/** Имя пользователя MySQL */
define('DB_USER', 'asl');

/** Пароль к базе данных MySQL */
define('DB_PASSWORD', 'qweQWE123!@#');

/** Имя сервера MySQL */
define('DB_HOST', 'localhost');

/** Кодировка базы данных для создания таблиц. */
define('DB_CHARSET', 'utf8mb4');

/** Схема сопоставления. Не меняйте, если не уверены. */
define('DB_COLLATE', '');

/**#@+
 * Уникальные ключи и соли для аутентификации.
 *
 * Смените значение каждой константы на уникальную фразу.
 * Можно сгенерировать их с помощью {@link https://api.wordpress.org/secret-key/1.1/salt/ сервиса ключей на WordPress.org}
 * Можно изменить их, чтобы сделать существующие файлы cookies недействительными. Пользователям потребуется авторизоваться снова.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         'SdCP[ga*j1>D}&QSQF-lLyr;z]ABxDT?|G2[^4onw!R(p4zwgo4W#@!{ jL[4 =7');
define('SECURE_AUTH_KEY',  'W.s#5}T^lmX4_9iK4v1bU:WLLJ7D^r~*2]KDzY$!?4}~@RRxFI{AFDNo:]m2sBx1');
define('LOGGED_IN_KEY',    'j0Bn3n@`iB8 aN;tQP+tVn[]Tr!`tgC:0;7p8c%OSuZWA$;)?I<h@d!cxmM!.}sJ');
define('NONCE_KEY',        '#R8,Hy>8V7)fZu%@9k?D!b9X7uBTIMM*oib^`voQI-:k^Ls~.If<o]z)^PAQ:y-l');
define('AUTH_SALT',        '8P$3EFDl^g=(m~(g3FMvy,1 wkQ)60P?d=89ziUTI~x Ta/+DUk5P5]F5@]e2+|X');
define('SECURE_AUTH_SALT', '}|?&^a/]>g;|b;J$q3Tao]jeNFL+LBX[UKrNW<>zb$ZTPquU<Oz4>9iy3Q@r9xJg');
define('LOGGED_IN_SALT',   '4~vbM67x0H#~*LUj=ilT,~.8/aw/qjT/**HOoG FIUr.vkz>/eM).CLv[ZSQfq04');
define('NONCE_SALT',       'HYpHs*`;%HNCmJ>T+CH|8qbZ@E@h|T(89HoD*RytvPF +GWj}(pS`5ieC_Z<[)L<');

/**#@-*/

/**
 * Префикс таблиц в базе данных WordPress.
 *
 * Можно установить несколько сайтов в одну базу данных, если использовать
 * разные префиксы. Пожалуйста, указывайте только цифры, буквы и знак подчеркивания.
 */
$table_prefix  = 'wp_';

/**
 * Для разработчиков: Режим отладки WordPress.
 *
 * Измените это значение на true, чтобы включить отображение уведомлений при разработке.
 * Разработчикам плагинов и тем настоятельно рекомендуется использовать WP_DEBUG
 * в своём рабочем окружении.
 *
 * Информацию о других отладочных константах можно найти в Кодексе.
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
define('WP_DEBUG', false);

/* Это всё, дальше не редактируем. Успехов! */

/** Абсолютный путь к директории WordPress. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Инициализирует переменные WordPress и подключает файлы. */
require_once(ABSPATH . 'wp-settings.php');
