<?php
// Text
$_['text_footer'] 	= '<a target="_blank" href="http://myopencart.com/">ocStore</a> &copy; 2009-' . date('Y') . ' All Rights Reserved.';
$_['text_version'] 	= 'Version ocStore %s';