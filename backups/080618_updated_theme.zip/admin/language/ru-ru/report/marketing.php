<?php
// Heading
$_['heading_title']    = 'Отчет по маркетингу';

// Text
$_['text_list']         = 'Список по маркетингу';
$_['text_all_status']   = 'Все статусы';

// Column
$_['column_campaign']  = 'Название компании';
$_['column_code']      = 'Код';
$_['column_clicks']    = 'Кликов';
$_['column_orders']    = 'Кол-во заказов';
$_['column_total']     = 'Итого';

// Entry
$_['entry_date_start'] = 'Дата начала:';
$_['entry_date_end']   = 'Дата окончания:';
$_['entry_status']     = 'Статусы заказов:';