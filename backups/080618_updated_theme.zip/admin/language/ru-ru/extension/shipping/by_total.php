<?php
// Heading
$_['heading_title']      = 'Доставка в зависимости от суммы заказа';

// Text
$_['text_shipping']      = 'Доставка';
$_['text_success']       = 'Настройки модуля обновлены!';

// Entry
$_['entry_rate']         = 'Расценки:<br /><span class="help">Например: 500:10.00,700:12.00 Сумма:Цена,Сумма:Цена, и т.д.</span>';
$_['entry_tax_class']    = 'Налоговый класс:';
$_['entry_geo_zone']     = 'Географическая зона:';
$_['entry_status']       = 'Статус:';
$_['entry_sort_order']   = 'Порядок сортировки:';

// Error
$_['error_permission']   = 'У вас нет прав для управления этим модулем!';
?>
