<?php
$_['heading_title'] = 'Яндекс.Касса (QIWI Wallet)';
?>