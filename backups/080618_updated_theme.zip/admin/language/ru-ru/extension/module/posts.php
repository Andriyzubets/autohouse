<?php
// Heading
$_['heading_title']    = '<a href="http://ocmod.net" target="_blank" data-toggle="tooltip" data-placement="right" data-original-title="Скачано с сайта ocmod.net"><i class="fa fa-cloud-download" aria-hidden="true" style="margin-right: 5px;"></i>Блог Статьи</a>';

$_['text_module']      = 'Модуль';
$_['text_success']     = 'Успешно!';
$_['text_edit']        = 'Редактировать';

// Entry
$_['entry_status']     = 'Статус';

// Error
$_['error_permission'] = 'У вас нет прав!';