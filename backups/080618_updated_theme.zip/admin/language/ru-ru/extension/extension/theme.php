<?php
// Heading
$_['heading_title']    = 'Шаблоны';

// Text
$_['text_success']     = 'Тема успешно изменена!';
$_['text_list']        = 'Список шаблонов';

// Column
$_['column_name']      = 'Название';
$_['column_status']    = 'Статус';
$_['column_action']    = 'Действие';

// Error
$_['error_permission'] = 'Внимание: У вас нет разрешения на изменение настроек шаблона!';
