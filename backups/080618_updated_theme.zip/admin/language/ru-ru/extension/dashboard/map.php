<?php
// Heading
$_['heading_title'] = 'Продажи по странам';

// Text
$_['text_extension']   = 'Панель управления';
$_['text_success']     = 'Панель продаж по странам успешно изменена!';
$_['text_edit']        = 'Редактировать';
$_['text_order']    = 'Заказы';
$_['text_sale']     = 'Продажи';

// Entry
$_['entry_status']     = 'Статус';
$_['entry_sort_order'] = 'Сортировка';
$_['entry_width']      = 'Ширина';

// Error
$_['error_permission'] = 'У вас нет прав для управления этим модулем!';
