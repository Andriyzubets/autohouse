<?php
// Heading
$_['heading_title']           = 'Инструменты OC Team';

// Text
$_['text_install']            = 'Установить';
$_['text_uninstall']          = 'Удалить';
$_['text_open']               = 'Открыть';

// Column
$_['column_name']             = 'Название инструмента';
$_['column_description']      = 'Описание инструмента';
$_['column_action']           = 'Действие';

// Error
$_['error_permission']        = 'У вас нет прав для управления Инструментами!';
?>
